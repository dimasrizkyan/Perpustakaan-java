Nama    : Revan Fatkhurezi Desviansyah
NIM     : 20230040097
Kelas   : TI23E

Tugas   : Aplikasi Perpustakaan (Tampilkan & Tambah Buku)

Cara menjalankan:
1. Jalankan XAMPP dan aktifkan MySQL
2. Import file `perpustakaan.sql` ke phpMyAdmin
3. Compile dengan:
   javac -cp "lib/*" -d bin src/*.java
4. Jalankan dengan:
   java -cp "bin;lib/*" Main
